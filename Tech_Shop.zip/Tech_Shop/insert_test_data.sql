# Insert data into the tables

USE tech_shop_products;
INSERT INTO products (model,type_of_device,price) VALUES ("iPhone 11", "Phone", 150);
